// pages/myindex/myindex.js
//和风天气位置转换成locationid
var util= require('../../utils/util.js');
// 获取当前时间年月日，正确时间需要换算一下
var timestamp = Date.parse(new Date());
var date = new Date(timestamp);

Page({
    /**
     * 页面的初始数据
     */
    data: {
        // 登陆获取用户信息
        nickName:"未登录",
        src:"../../images/zzy.jpg",
        isLogin:false,

        // 获取日期
        year:date.getFullYear(),
        month:(date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1),
        day: date.getDate() < 10 ? '0' + date.getDate() : date.getDate(),

        // 用户选择及读取数据相关
        seed:0,
        letter:0,
        nowSeed:[false,false,false,false,false],
        nowLetter:[false,false,false,false,false],

        temp:-1,
        poemInfo:{},

        //天气
        region:['山东省','青岛市','黄岛区'],
        now:{},

      },

    //获取一个随机数，尚未实现
    suijishu:function() {
        this.setData({
            temp:0
        })
    },

    onLoad() {
        if (wx.getUserProfile) {
          this.setData({
            canIUseGetUserProfile: true,
            seed:0,
            letter:0
          })
        }
        this.suijishu();
        // console.log("year",date.getFullYear())
        this.getWeather();
     },
      // 获取用户信息
    getMyInfo: function(e) {
        // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
        wx.getUserProfile({
            desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
            success: (res) => {
                //console.log(res)
                this.setData({
                    isLogin:true,
                    src: res.userInfo.avatarUrl,
                    nickName: res.userInfo.nickName
                })
            }
        })
     },

     /**
      * 处理种子单机事件
      * @param {} e 
      */
    selectSeed:function(e){
        let seed=e.currentTarget.dataset.seedid;
        this.setData({
            seed:seed
        })
        console.log("选择的seed是：",seed);
        var tempSeed=[];
        for(var i=0;i<5;i++){
            if(i==seed)
            {
                tempSeed[i]=true;
            }else{
                tempSeed[i]=false;
            }
        }
        this.setData({
            nowSeed:tempSeed
        })
        console.log("seeddata",this.data.nowSeed)
    },

     /**
      * 处理信封单机事件
      * @param {} e 
      */
    selectLetter:function(e){
        let letter=e.currentTarget.dataset.letterid;
        this.setData({
            letter:letter
        })
        console.log("选择的letter是：",letter);
        var tempLetter=[];
        for(var i=0;i<5;i++){
            if(i==letter)
            {
                tempLetter[i]=true;
            }else{
                tempLetter[i]=false;
            }
        }
        this.setData({
            nowLetter:tempLetter
        })
        console.log("data",this.data.nowLetter)
    },

    /**
     * 查询数据，携带跳转
     */
    gotoMyRead:function () {
        //获取要携带的数据库数据,尚未实现
        wx.cloud.database().collection('poem')
        .where({
            //里面写条件
            seed:this.data.seed,
            letter:this.data.letter
        })
        .get()            
        .then(res =>{
            console.log('请求poem成功',res.data)
            let poemList=res.data
            this.setData({
              //动态的将数据库中的数据存放到数组中
              poemInfo:poemList[0],

            })
            console.log("poemInfo:",this.data.poemInfo);
            console.log("temp:",this.data.temp);
            //携带查询到的记录进行页面跳转
            wx.setStorageSync('indexdata', this.data)
            wx.navigateTo({
                url: '../myread/myread'
            })
        })
        .catch(err =>{
            console.log('请求poem失败',err)
        })
    },

    /**
     * 更新位置时触发
     */
    bindRegionChange:function(e){
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region:e.detail.value
        });
        this.getWeather();
    },
    //获取天气信息
    getWeather:function(){
        var that=this;
        wx.request({
          url: 'https://devapi.qweather.com/v7/weather/now?',
          data:{
              location:util.getLocationID(that.data.region[1]),
            // location:"青岛",
            // location:that.data.region[1],
            key:'a20f068272b2436dad7f7fd468df7839'
          },
          success:res=>{
              console.log("region:",that.data.region);
              console.log("region:",that.data.region[1]);
              console.log("data:",res.data);
              this.setData({
                  now:res.data.now,
              })
          }
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})