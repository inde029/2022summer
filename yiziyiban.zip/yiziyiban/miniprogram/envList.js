const envList = [{"envId":"cloud1-9g19l5pe3087cf5e","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}