// pages/myread/myread.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        nickName:"未登录",
        src:"../../images/zzy.jpg",
        year:2022,
        month:8,
        day:25,
        temp:-1,
        color:'bisque',
        flowersrc:"",
        poemInfo:[],
        sentence:"",
        author:"",

        maskHidden: false, //控制海报显示
        imagePath:"",

        //天气
        region:['山东省','青岛市','黄岛区'],
        nowWeather:"未知"
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        var indexdata=wx.getStorageSync('indexdata')
        console.log("getdata",indexdata)
        this.setData({
            nickName:indexdata.nickName,
            src:indexdata.src,
            year:indexdata.year,
            month:indexdata.month,
            day:indexdata.day,
            temp:Math.ceil(Math.random()*2),
            color:indexdata.poemInfo.color,
            flowersrc:indexdata.poemInfo.flowersrc,
            poemInfo:indexdata.poemInfo.poems,
            region:indexdata.region,
            nowWeather:indexdata.now.text,
        })
        console.log("temp1:",this.data.temp)
        this.setData({
            sentence:this.data.poemInfo[0].sentence,
            author:this.data.poemInfo[0].author
        })
    },
    /**
     * 点击分享
     */
    onClickShare:function (params) {
        var that = this;
        wx.showToast({
          title: '图片生成中...',
          icon: 'loading',
          duration: 1000
        });
    
        that.createImage();
        setTimeout(function () {
          // wx.hideToast()
          that.setData({
            maskHidden: true
          });
        }, 1000);
    },

    /**
     * 
     */
    //画图
    createImage: function () {
        var that = this;
        var context;
        wx.createSelectorQuery()
        .select('#myCanvas') // 在 WXML 中填入的 id
        .node(({ node: canvas }) => {
            context = canvas.getContext('2d')
        })
        .exec()

        // 旧版 canvas 不能修改宽高,画布大小初始化
        wx.createSelectorQuery()
        .select('#myCanvas') // 在 WXML 中填入的 id
        .fields({ node: true, size: true })
        .exec((res) => {
            // Canvas 对象
            const canvas = res[0].node
            // Canvas 画布的实际绘制宽高
            const renderWidth = res[0].width
            const renderHeight = res[0].height
            // Canvas 绘制上下文
            const ctx = canvas.getContext('2d')

            // 初始化画布大小
            const dpr = wx.getWindowInfo().pixelRatio
            canvas.width = renderWidth * dpr
            canvas.height = renderHeight * dpr
            ctx.scale(dpr, dpr)


            context.clearRect(0,0, canvas.width, canvas.height);
            context.fillStyle=this.data.color;//背景色
            context.fillRect(0, 0, 375, 660);// （X轴坐标，Y轴坐标，宽，高）
            context.save();

            //开始画
            //文字部分
            context.font = "18px sans-serif";
            context.fillStyle='#333333';

            //绘制昵称
            context.fillText(this.data.nickName, 90, 70);
            context.textAlign='left';

            context.font = "16px sans-serif";
            //绘制日期
            var strdate=this.data.year+"年"+this.data.month+"月"+this.data.day+"日";
            context.fillText(strdate, 230, 40);
            //绘制位置和天气
            var strpos=this.data.region[0]+" "+this.data.region[1]+" "+this.data.region[2]+" "+this.data.nowWeather;
            context.fillText(strpos, 160, 70);

            //绘制诗句
            context.font = "18px sans-serif";
            var lineWidth = 0;
            var lastSubStrIndex = 0; //每次开始截取的字符串的索引
            var initHeight=150;
            var leftWidth=50;
            var canvasWidth=280;//每行宽度
            var str="        "+this.data.sentence;
            for (let i = 0; i < str.length; i++) {
                lineWidth += context.measureText(str[i]).width;
                if (lineWidth > canvasWidth) {
                    context.fillText(str.substring(lastSubStrIndex, i), leftWidth, initHeight); //绘制截取部分
                    initHeight += 24; //16为字体的高度
                    lineWidth = 0;
                    lastSubStrIndex = i;
                }
                if (i == str.length - 1) { //绘制剩余部分
                    context.fillText(str.substring(lastSubStrIndex, i + 1), leftWidth, initHeight);
                }
            }
            //作者
            var str2="——"+this.data.author;
            context.fillText(str2, leftWidth+180, initHeight+48);
            context.save();

            // 二维码
            const image = canvas.createImage()
            image.onload = () => {
                context.drawImage(
                    image,
                    240,//x
                    470,//y
                    100,//宽
                    100,//高
                )
            }
            image.src ="../../images/xiaochengxu.jpg";
            context.save();

            //头像
            // ctx.beginPath()//开始创建一个路径
            // ctx.arc(35, 25, 15, 0, 2 * Math.PI, false)//画一个圆形裁剪区域
            // ctx.clip()//裁剪
            // ctx.closePath();
            // ctx.drawImage(headImageLocal, 20, 10, 30, 30);
            // ctx.draw(true);
            // ctx.restore()//恢复之前保存的绘图上下文


            var avatarurl_width = 60; //绘制的头像宽度
            var avatarurl_heigth = 60; //绘制的头像高度
            var avatarurl_x = 20; //绘制的头像在画布上的位置
            var avatarurl_y = 20; //绘制的头像在画布上的位置

            // context.beginPath();//开始创建一个路径
            // context.arc(avatarurl_width / 2 + avatarurl_x, avatarurl_heigth / 2 + avatarurl_y, avatarurl_width / 2, 0, Math.PI * 2, false);//画一个圆形裁剪区域
            // context.clip();//裁剪画布
            const image2 = canvas.createImage();
            image2.onload = () => {
                context.drawImage(
                    image2,
                    avatarurl_x,//x
                    avatarurl_y,//y
                    avatarurl_width,//宽
                    avatarurl_heigth,//高
                    )
            }
            image2.src =that.data.src;
            ctx.closePath();
            context.restore();
            context.save();

            //花
            const image3 = canvas.createImage()
            image3.onload = () => {
                context.drawImage(
                    image3,
                    70,//x
                    280,//y
                    150,//宽
                    300,//高
                )
            }
            image3.src =that.data.flowersrc;
            context.save();

            //将生成好的图片保存到本地，需要延迟一会，绘制期间耗时
            setTimeout(function () {
                wx.canvasToTempFilePath({
                    canvas: canvas,
                success: function (res) {
                    var tempFilePath = res.tempFilePath;
                    that.setData({
                        imagePath: tempFilePath
                    });
                },
                fail: function (res) {
                    //console.log(res);
                }
                });
            }, 2000); 
        })

    },

    /**
     * 点击保存
     */
    //点击保存到相册
    baocun: function () {
        var that = this
        wx.saveImageToPhotosAlbum({
            filePath: that.data.imagePath,
            success(res) {
                wx.showModal({
                    content: '保存成功，快去分享吧~',
                    showCancel: false,
                    success: function (res) {
                        if (res.confirm) {
                            /* 该隐藏的隐藏 */
                            that.setData({
                                maskHidden: false
                            })
                        }
                    },
                    fail: function (res) {
                        // console.log()
                    }
                })
            }
        })
    },

    /**
     * 跳转到信箱
     */
    gotoMyLetter:function () {
        wx.setStorageSync('indexdata', this.data)
        wx.navigateTo({
            url: '../myletter/myletter'
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.setData({
            maskHidden: false
          });
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})