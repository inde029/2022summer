// index.js
var util= require('../../utils/util.js')

Page({
    /**
     * 获取实况天气
     */
    data:{
        region:['山东省','青岛市','崂山区'],
        now:{},
    },
    
    /**
     * 更新位置时触发
     */
    bindRegionChange:function(e){
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region:e.detail.value
        });
        this.getWeather();
    },

    getWeather:function(){
        var that=this;
        wx.request({
          url: 'https://devapi.qweather.com/v7/weather/now?',
          data:{
              location:util.getLocationID(that.data.region[1]),
            // location:"青岛",
            // location:that.data.region[1],
            key:'a20f068272b2436dad7f7fd468df7839'
          },
          success:res=>{
              console.log("region:",that.data.region);
              console.log("region:",that.data.region[1]);
              console.log("data:",res.data);
              this.setData({
                  now:res.data.now,
              })
          }
        })
    },


    /**
     * 生命周期函数
     */
    onLoad:function(options){
        this.getWeather();
    },

})
