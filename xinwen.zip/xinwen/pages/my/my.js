// pages/my/my.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        nickName:"未登录",
        src:"/images/index.png",
        newsList:[
        //     {
        //     id: '305670',
        //     title: '我校在第八届安徽省“互联网+”大学生创新创业大赛再创佳绩',
        //     poster: 'https://gaopursuit.oss-cn-beijing.aliyuncs.com/2022/newsimage3.jpg',
        //     content: '7月4日—8月10日，由安徽省教育厅、合肥市人民政府、淮北市人民政府联合主办的第八届安徽省“互联网+”大学生创新创业大赛暨中国国际“互联网+”大学生创新创业大赛选拔赛在线上举办。我校参赛项目团队历经省级复赛网评、决赛路演答辩、金奖排位赛等多轮次比拼，斩获金奖3项、银奖10项、铜奖23项，其中3个项目由省赛组委会推荐入围国赛。',
        //     add_date: '2022-08-11'
        // }
        ],
        src:'',
        nickName:'',
        isLogin:false,
        num:0
    },

    onLoad() {
        if (wx.getUserProfile) {
          this.setData({
            canIUseGetUserProfile: true
          })
        }
        if(this.data.isLogin){
            this.getMyFavorites()
        }
    },

    goToDetail: function(e) {
        //获取携带的data-id数据
        let id = e.currentTarget.dataset.id;
        console.log("jumpid:",id);
        //携带新闻id进行页面跳转
        wx.navigateTo({
          url: '../detail/detail?id=' + id
        })
      },
    // 获取用户信息
    getMyInfo: function(e) {
        // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
        wx.getUserProfile({
            desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
            success: (res) => {
                //console.log(res)
                this.setData({
                    isLogin:true,
                    src: res.userInfo.avatarUrl,
                    nickName: res.userInfo.nickName
                })
                this.getMyFavorites();
            }
        })
    },
    /**
     * 获取收藏列表
     */
    getMyFavorites:function(){
        let info=wx.getStorageInfoSync();
        console.log("info:",info);
        let keys=info.keys;
        let num=keys.length;
        let myList=[];
        for(var i=0;i<num;i++)
        {
            let obj=wx.getStorageSync(keys[i]);
            myList.push(obj);
        }
        //更新收藏列表
        this.setData({
            newsList:myList,
            num:num
        })
    },
    /**
     * 
     */
    onShow:function(){
        //已登录更新收藏列表
        if(this.data.isLogin){
            this.getMyFavorites()
        }
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})