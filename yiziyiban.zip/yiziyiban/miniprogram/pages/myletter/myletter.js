// pages/myletter/myletter.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        //用户信息
        nickName:"未登录",
        src:"../../images/zzy.jpg",
        date:"2022年8月31日",
        color:"bisque",
        //天气
        region:['山东省','青岛市','黄岛区'],
        nowWeather:"未知",

        //帖子内容
        inputValue:'',
        sentence:"花开是念一封远方的来信，念一字，开一瓣。",
        author:"作者",
        list:[],

        //发帖
        letter:"空",

    },

    /**
     * 获取数据库信息
     */
    getLetterList:function () {
        //ES6简洁写法（推荐此种写法）
        wx.cloud.database().collection('letters').get()
        //查询操作
        .then(res =>{
            console.log('请求数据成功',res.data)
            let list=res.data
            list.reverse()
            this.setData({
                //动态的将数据库中的数据存放到list数组中
                list:list
            })
        })
        .catch(err =>{
            console.log('请求失败',err)
        })
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        var indexdata=wx.getStorageSync('indexdata')
        console.log("mylettergetdata",indexdata)
        this.setData({
            nickName:indexdata.nickName,
            src:indexdata.src,
            date:indexdata.year+"年"+indexdata.month+"月"+indexdata.day+"日",
            color:indexdata.color,
            region:indexdata.region,
            nowWeather:indexdata.nowWeather,
        })
        this.getLetterList();
    },

    /**
     * 投递单击事件
     */
    bindTextAreaBlur: function(e) {
        console.log(e.detail.value)
        this.setData({
            letter:e.detail.value
        })
    },
    
    submitSentence:function () {
        //必须设that 并延时，否则获取不到
        var that=this;
        setTimeout(function () {
            console.log("letter",that.data.letter)
            //添加到数据库
            if(that.data.letter){
                wx.cloud.database().collection('letters')
                .add({//添加一行数据
                data:{
                    color:that.data.color,
                    date:that.data.date,
                    letter:that.data.letter,
                    name:that.data.nickName
                }
                })
                .then(res =>{
                    console.log('添加数据成功');
                    wx.showToast({
                        title: '投递成功~',
                    })
                    this.setData({
                        letter:''
                    })
                })
                .catch(err =>[
                    console.log('添加数据失败')
                ])
                setTimeout(function () {
                    that.setData({
                        inputValue:''
                    })
                    that.getLetterList();            
                },1000)
            }else{
                wx.showToast({
                    title: '留言不能为空',
                    icon:'error',
                })
            }
        }, 1000);
        
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})